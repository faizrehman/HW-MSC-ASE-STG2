package Controller;

import java.util.HashMap;

import Model.Booking;
import Model.Flight;

public class DataLoadController {

	/*public HashMap<String, Booking> getBookingList() {
		return bookingList;
	}



	public HashMap<String, Flight> getFlightList() {
		return flightList;
	}*/
	
}
