package exception;

public class InvalidDataException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4846401845167978061L;

	public InvalidDataException(String message) {
		super(message);
	}
}
