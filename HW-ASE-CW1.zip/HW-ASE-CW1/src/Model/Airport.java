package Model;

/*Added By Amer*/
public class Airport {
	private Integer terminalID;
	private String  airPortName;
	
	
	public Integer getTerminalID() {
		return terminalID;
	}

	public void setTerminalID(Integer terminalID) {
		this.terminalID = terminalID;
	}

	public String getAirPortName() {
		return airPortName;
	}

	public void setAirPortName(String airPortName) {
		this.airPortName = airPortName;
	}




}
